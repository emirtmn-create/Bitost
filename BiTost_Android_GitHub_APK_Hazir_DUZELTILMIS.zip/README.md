# Bi'Tost Kasa — Düzeltilmiş Sürüm

Yeni uygulama kimliği: `com.bitost.kasa.emir2026`

Bu sürüm önceki APK ile çakışmaması için farklı paket adıyla hazırlanmıştır.
