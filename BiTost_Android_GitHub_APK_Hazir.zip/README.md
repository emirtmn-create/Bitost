# Bi'Tost Yönetim

Android gelir-gider uygulaması.

## Telefonda APK oluşturma
1. Bu klasörün tamamını GitHub'da yeni bir depoya yükle.
2. **Actions** sekmesine gir.
3. **BiTost APK Oluştur** iş akışını aç.
4. **Run workflow** düğmesine bas.
5. İşlem tamamlanınca alttaki **BiTost-Yonetim-APK** dosyasını indir.
6. ZIP'i açıp `app-debug.apk` dosyasını telefona kur.
