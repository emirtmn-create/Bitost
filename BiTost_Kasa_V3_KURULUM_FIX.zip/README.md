# Bi'Tost Kasa V3

Kurulum sorunu için hazırlanmış temiz ve release-imzalı sürüm.

- Paket: `com.bitost.kasa.v3`
- minSdk: 23
- targetSdk: 35
- Sürüm: 2.0 (10)
- APK: V1 + V2 + V3 + V4 imzalı release APK
